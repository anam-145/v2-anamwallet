// IremboGov mini-app
console.log("IremboGov app initialized");