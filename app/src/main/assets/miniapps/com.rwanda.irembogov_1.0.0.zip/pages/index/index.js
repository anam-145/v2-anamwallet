// IremboGov 페이지 초기화
console.log("IremboGov mini-app loaded");