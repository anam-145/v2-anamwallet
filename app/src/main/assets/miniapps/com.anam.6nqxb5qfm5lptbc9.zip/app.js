// 해운대 뉴스 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Haeundae News mini-app launched');
  },
  
  onShow() {
    console.log('Haeundae News mini-app shown');
  },
  
  onHide() {
    console.log('Haeundae News mini-app hidden');
  }
};