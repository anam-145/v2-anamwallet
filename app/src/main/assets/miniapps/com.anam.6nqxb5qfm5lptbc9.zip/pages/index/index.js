// 비온미디어 메인 페이지 로직
console.log('Bonmedia page loaded');

// 페이지 로드 시 자동으로 비온미디어로 이동
window.location.href = "https://www.bonmedia.kr/";