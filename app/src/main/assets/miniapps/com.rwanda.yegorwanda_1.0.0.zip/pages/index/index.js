// YEGO Rwanda 페이지 초기화
console.log("YEGO Rwanda mini-app loaded");