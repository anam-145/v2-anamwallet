// YEGO Rwanda mini-app
console.log("YEGO Rwanda app initialized");