// University of Liberia 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('University of Liberia mini app started');
  },
  
  onShow() {
    console.log('University of Liberia mini app shown');
  },
  
  onHide() {
    console.log('University of Liberia mini app hidden');
  }
};