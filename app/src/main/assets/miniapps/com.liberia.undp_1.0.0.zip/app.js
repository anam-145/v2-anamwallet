// UNDP 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('UNDP mini app started');
  },
  
  onShow() {
    console.log('UNDP mini app shown');
  },
  
  onHide() {
    console.log('UNDP mini app hidden');
  }
};