// Job in Rwanda mini-app
console.log("Job in Rwanda app initialized");