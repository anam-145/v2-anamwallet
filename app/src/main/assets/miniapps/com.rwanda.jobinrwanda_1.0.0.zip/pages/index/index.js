// Job in Rwanda 페이지 초기화
console.log("Job in Rwanda mini-app loaded");