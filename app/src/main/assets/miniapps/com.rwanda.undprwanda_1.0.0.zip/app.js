// UNDP Rwanda mini-app
console.log("UNDP Rwanda app initialized");