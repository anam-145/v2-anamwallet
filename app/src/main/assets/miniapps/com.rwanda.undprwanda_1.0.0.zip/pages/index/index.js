// UNDP Rwanda 페이지 초기화
console.log("UNDP Rwanda mini-app loaded");