// The New Times 페이지 초기화
console.log("The New Times mini-app loaded");