// The New Times mini-app
console.log("The New Times app initialized");