// University of Rwanda mini-app
console.log("University of Rwanda app initialized");