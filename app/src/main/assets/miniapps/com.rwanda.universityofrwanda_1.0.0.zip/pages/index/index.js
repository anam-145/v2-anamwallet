// University of Rwanda 페이지 초기화
console.log("University of Rwanda mini-app loaded");