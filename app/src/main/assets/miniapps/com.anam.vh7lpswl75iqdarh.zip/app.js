// 해운대 뉴스 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Haeundae News Mini App Started');
  },
  
  onShow() {
    console.log('Haeundae News Mini App Shown');
  },
  
  onHide() {
    console.log('Haeundae News Mini App Hidden');
  }
};