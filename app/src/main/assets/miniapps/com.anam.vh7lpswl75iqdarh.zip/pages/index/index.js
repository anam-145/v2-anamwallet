// 부산일보 메인 페이지 로직
console.log('Busan Ilbo page loaded');

// 페이지 로드 시 자동으로 부산일보 모바일로 이동
window.location.href = "https://mobile.busan.com/";