// Liberia HR Jobs 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Liberia HR Jobs mini app started');
  },
  
  onShow() {
    console.log('Liberia HR Jobs mini app shown');
  },
  
  onHide() {
    console.log('Liberia HR Jobs mini app hidden');
  }
};