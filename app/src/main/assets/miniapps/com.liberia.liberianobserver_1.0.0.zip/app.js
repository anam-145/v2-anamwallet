// Liberian Observer 미니앱 생명주기 정의

window.App = {
  onLaunch() {
    console.log('Liberian Observer mini app started');
  },
  
  onShow() {
    console.log('Liberian Observer mini app shown');
  },
  
  onHide() {
    console.log('Liberian Observer mini app hidden');
  }
};